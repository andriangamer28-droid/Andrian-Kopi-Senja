<?php

namespace App\Http\Controllers;

use App\Models\Peminjaman;
use App\Models\Anggota;
use App\Models\Buku;
use Illuminate\Http\Request;
use Carbon\Carbon;

class PeminjamanController extends Controller
{
    public function index()
    {
        $peminjamans = Peminjaman::with(['anggota', 'buku'])->latest()->paginate(10);
        return view('peminjaman.index', compact('peminjamans'));
    }

    public function create()
    {
        $anggotas = Anggota::all();
        $bukus = Buku::where('stok', '>', 0)->get();
        return view('peminjaman.create', compact('anggotas', 'bukus'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'anggota_id' => 'required|exists:anggotas,id',
            'buku_id' => 'required|exists:bukus,id',
            'tanggal_pinjam' => 'required|date',
        ]);

        $buku = Buku::findOrFail($request->buku_id);

        // Cek stok buku
        if ($buku->stok <= 0) {
            return back()->with('error', 'Stok buku tidak mencukupi.');
        }

        // Kurangi stok buku
        $buku->decrement('stok');

        // Simpan data peminjaman
        Peminjaman::create([
            'anggota_id' => $request->anggota_id,
            'buku_id' => $request->buku_id,
            'tanggal_pinjam' => $request->tanggal_pinjam,
            'status' => 'dipinjam',
        ]);

        return redirect()->route('peminjaman.index')
            ->with('success', 'Peminjaman berhasil dicatat.');
    }

    public function show(Peminjaman $peminjaman)
    {
        $denda = $peminjaman->hitungDenda();
        return view('peminjaman.show', compact('peminjaman', 'denda'));
    }

    // Proses pengembalian buku
    public function kembalikan(Peminjaman $peminjaman)
    {
        if ($peminjaman->status === 'dikembalikan') {
            return back()->with('error', 'Buku sudah dikembalikan.');
        }

        $buku = $peminjaman->buku;
        $buku->increment('stok');

        $peminjaman->update([
            'tanggal_kembali' => Carbon::now(),
            'status' => 'dikembalikan',
            'denda' => $peminjaman->hitungDenda(),
        ]);

        return redirect()->route('peminjaman.index')
            ->with('success', 'Buku berhasil dikembalikan. Denda: Rp ' . number_format($peminjaman->denda, 0, ',', '.'));
    }

    public function destroy(Peminjaman $peminjaman)
    {
        // Jika peminjaman masih aktif, kembalikan stok sebelum hapus
        if ($peminjaman->status === 'dipinjam') {
            $peminjaman->buku->increment('stok');
        }

        $peminjaman->delete();

        return redirect()->route('peminjaman.index')
            ->with('success', 'Data peminjaman berhasil dihapus.');
    }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Peminjaman extends Model
{
    use HasFactory;

     use HasFactory;

    /**
     * Nama tabel yang digunakan oleh model ini.
     *
     * @var string
     */
    protected $table = 'peminjamans';

    protected $fillable = [
        'anggota_id', 'buku_id', 'tanggal_pinjam',
        'tanggal_kembali', 'status', 'denda'
    ];

    protected $casts = [
        'tanggal_pinjam' => 'date',
        'tanggal_kembali' => 'date',
    ];

    public function anggota()
    {
        return $this->belongsTo(Anggota::class);
    }

    public function buku()
    {
        return $this->belongsTo(Buku::class);
    }

    // Logika hitung denda (Rp 2000 per hari keterlambatan)
    public function hitungDenda()
    {
        if ($this->status === 'dikembalikan' || !$this->tanggal_kembali) {
            return $this->denda;
        }

        $batasWaktu = Carbon::parse($this->tanggal_pinjam)->addDays(7); // asumsi lama pinjam 7 hari
        $hariIni = Carbon::now();

        if ($hariIni->greaterThan($batasWaktu)) {
            $selisihHari = $hariIni->diffInDays($batasWaktu);
            return $selisihHari * 2000;
        }

        return 0;
    }
}
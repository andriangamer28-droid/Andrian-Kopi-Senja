<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Detail Buku') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h3 class="text-lg font-medium">{{ $buku->judul }}</h3>
                            <dl class="mt-4 space-y-2">
                                <div><span class="font-medium">Penulis:</span> {{ $buku->penulis }}</div>
                                <div><span class="font-medium">Penerbit:</span> {{ $buku->penerbit }}</div>
                                <div><span class="font-medium">Tahun:</span> {{ $buku->tahun_terbit }}</div>
                                <div><span class="font-medium">ISBN:</span> {{ $buku->isbn }}</div>
                                <div><span class="font-medium">Kategori:</span> {{ $buku->kategori->nama }}</div>
                                <div><span class="font-medium">Stok:</span> {{ $buku->stok }}</div>
                            </dl>
                        </div>
                    </div>

                    <div class="mt-6">
                        <a href="{{ route('buku.index') }}" class="text-sm text-gray-600 hover:text-gray-900">&larr; Kembali ke daftar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
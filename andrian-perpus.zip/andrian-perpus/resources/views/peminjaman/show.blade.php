<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight flex items-center">
            <span class="mr-2">🔍</span> Detail Peminjaman
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-2xl border border-gray-100 overflow-hidden">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-6">
                        <h3 class="text-xl font-bold text-gray-900">Peminjaman #{{ $peminjaman->id }}</h3>
                        <span class="px-3 py-1 text-sm rounded-full {{ $peminjaman->status == 'dipinjam' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800' }}">
                            {{ ucfirst($peminjaman->status) }}
                        </span>
                    </div>

                    <div class="grid md:grid-cols-2 gap-6 mb-8">
                        <div class="space-y-1">
                            <p class="text-sm text-gray-500">Anggota</p>
                            <p class="font-medium">{{ $peminjaman->anggota->nama }}</p>
                            <p class="text-sm text-gray-500">{{ $peminjaman->anggota->email }}</p>
                        </div>
                        <div class="space-y-1">
                            <p class="text-sm text-gray-500">Buku</p>
                            <p class="font-medium">{{ $peminjaman->buku->judul }}</p>
                            <p class="text-sm text-gray-500">{{ $peminjaman->buku->penulis }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Tanggal Pinjam</p>
                            <p class="font-medium">{{ $peminjaman->tanggal_pinjam->format('d F Y') }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Tanggal Kembali</p>
                            <p class="font-medium">{{ $peminjaman->tanggal_kembali ? $peminjaman->tanggal_kembali->format('d F Y') : 'Belum dikembalikan' }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Batas Pengembalian</p>
                            <p class="font-medium">{{ $peminjaman->tanggal_pinjam->addDays(7)->format('d F Y') }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Denda</p>
                            <p class="font-medium text-lg">Rp {{ number_format($denda, 0, ',', '.') }}</p>
                        </div>
                    </div>

                    <div class="flex flex-wrap gap-3 mt-8">
                        @if($peminjaman->status == 'dipinjam')
                        <form action="{{ route('peminjaman.kembalikan', $peminjaman) }}" method="POST">
                            @csrf @method('PATCH')
                            <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition" onclick="return confirm('Konfirmasi pengembalian buku?')">
                                Kembalikan Buku
                            </button>
                        </form>
                        @endif
                        <form action="{{ route('peminjaman.destroy', $peminjaman) }}" method="POST">
                            @csrf @method('DELETE')
                            <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition" onclick="return confirm('Hapus data peminjaman ini?')">
                                Hapus Data
                            </button>
                        </form>
                        <a href="{{ route('peminjaman.index') }}" class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition">
                            Kembali ke Daftar
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
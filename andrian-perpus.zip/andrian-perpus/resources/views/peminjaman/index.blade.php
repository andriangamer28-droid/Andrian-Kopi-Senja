<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight flex items-center">
            <span class="mr-2">🔄</span> Data Peminjaman
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-2xl border border-gray-100 overflow-hidden">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-gray-900">Daftar Peminjaman Buku</h3>
                        <a href="{{ route('peminjaman.create') }}" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-lg text-sm font-medium text-white hover:bg-indigo-700 transition shadow-sm">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                            Pinjam Buku
                        </a>
                    </div>

                    @if(session('success'))
                        <div class="bg-green-50 border-l-4 border-green-400 p-4 mb-6 rounded">
                            <p class="text-green-700">{{ session('success') }}</p>
                        </div>
                    @endif

                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Anggota</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Buku</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tgl Pinjam</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tgl Kembali</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Denda</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                @foreach($peminjamans as $pinjam)
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-4 font-medium">{{ $pinjam->anggota->nama }}</td>
                                    <td class="px-4 py-4">{{ $pinjam->buku->judul }}</td>
                                    <td class="px-4 py-4">{{ $pinjam->tanggal_pinjam->format('d/m/Y') }}</td>
                                    <td class="px-4 py-4">{{ $pinjam->tanggal_kembali ? $pinjam->tanggal_kembali->format('d/m/Y') : '-' }}</td>
                                    <td class="px-4 py-4">
                                        <span class="px-2 py-1 text-xs rounded-full {{ $pinjam->status == 'dipinjam' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800' }}">
                                            {{ $pinjam->status }}
                                        </span>
                                    </td>
                                    <td class="px-4 py-4">Rp {{ number_format($pinjam->denda, 0, ',', '.') }}</td>
                                    <td class="px-4 py-4 text-sm">
                                        <a href="{{ route('peminjaman.show', $pinjam) }}" class="text-indigo-600 hover:underline mr-2">Detail</a>
                                        @if($pinjam->status == 'dipinjam')
                                        <form action="{{ route('peminjaman.kembalikan', $pinjam) }}" method="POST" class="inline mr-2">
                                            @csrf @method('PATCH')
                                            <button type="submit" class="text-green-600 hover:underline" onclick="return confirm('Kembalikan buku?')">Kembalikan</button>
                                        </form>
                                        @endif
                                        <form action="{{ route('peminjaman.destroy', $pinjam) }}" method="POST" class="inline">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Hapus data?')">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-6">{{ $peminjamans->links() }}</div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Kategori;
use App\Models\Buku;
use App\Models\Anggota;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Kategori
        $kategori1 = Kategori::create(['nama' => 'Fiksi', 'deskripsi' => 'Buku fiksi']);
        $kategori2 = Kategori::create(['nama' => 'Non-Fiksi', 'deskripsi' => 'Buku non-fiksi']);

        // Buku
        Buku::create([
            'judul' => 'Laskar Pelangi',
            'penulis' => 'Andrea Hirata',
            'penerbit' => 'Bentang Pustaka',
            'tahun_terbit' => 2005,
            'isbn' => '9789793062792',
            'kategori_id' => $kategori1->id,
            'stok' => 3,
        ]);

        Buku::create([
            'judul' => 'Clean Code',
            'penulis' => 'Robert C. Martin',
            'penerbit' => 'Prentice Hall',
            'tahun_terbit' => 2008,
            'isbn' => '9780132350884',
            'kategori_id' => $kategori2->id,
            'stok' => 2,
        ]);

        // Anggota
        Anggota::create([
            'nama' => 'Budi Santoso',
            'alamat' => 'Jl. Merdeka No. 10, Jakarta',
            'telepon' => '081234567890',
            'email' => 'budi@example.com',
        ]);
    }
}